// =====================================================================
// step3.js
// القسم 3: اختيار مستوى السعر لكل مادة رئيسية (شامل الألمنيوم الآن)
// =====================================================================

import { TIER_MATERIALS, FIXED_OR_CUSTOM_MATERIALS } from "./wizardOptions.js";
import { PRICE_TIERS, TIERED_PRICES } from "../constants/index.js";
import { t } from "../i18n.js";

const MATERIAL_LABEL_KEYS = {
  floorTilePerSqm: "materialFloorTile",
  interiorPaintPerSqm: "materialInteriorPaint",
  facadeStonePerSqm: "materialFacadeStone",
  windowsPerSqm: "materialWindows",
  railingPerMeter: "materialRailing",
  mainDoorPerUnit: "materialMainDoor",
  steelPerKg: "materialSteel",
  cementPerBag: "materialCement",
};

function tierMaterialBlock(material, choice) {
  const tiers = TIERED_PRICES[material.key];
  const tierKeys = [PRICE_TIERS.ECONOMY, PRICE_TIERS.STANDARD, PRICE_TIERS.PREMIUM, PRICE_TIERS.CUSTOM];
  const tierLabelKeys = {
    [PRICE_TIERS.ECONOMY]: "tierEconomy",
    [PRICE_TIERS.STANDARD]: "tierStandard",
    [PRICE_TIERS.PREMIUM]: "tierPremium",
    [PRICE_TIERS.CUSTOM]: "tierCustom",
  };
  const materialLabel = t(MATERIAL_LABEL_KEYS[material.key]);

  return `
    <div class="tier-material" data-field-wrapper="pricing.${material.key}.tier">
      <p class="tier-material-title">${materialLabel} <span class="unit-hint">(${material.unit})</span></p>
      <div class="btn-group" data-group>
        ${tierKeys
          .map((tier) => {
            const price = tier !== PRICE_TIERS.CUSTOM ? tiers[tier] : null;
            return `
            <button type="button"
              class="btn-choice ${choice.tier === tier ? "active" : ""}"
              data-field="pricing.${material.key}.tier"
              data-value="${tier}">
              ${t(tierLabelKeys[tier])}
              ${price != null ? `<span class="price-hint">· ${price} JOD</span>` : ""}
            </button>`;
          })
          .join("")}
      </div>
      ${
        choice.tier === PRICE_TIERS.CUSTOM
          ? `<input type="number" class="custom-price-input" dir="ltr"
              placeholder="${t("customPricePlaceholder")}"
              data-field="pricing.${material.key}.customPrice"
              data-type="number"
              value="${choice.customPrice ?? ""}" />`
          : ""
      }
      <span class="field-error" data-error-for="${material.key}"></span>
    </div>
  `;
}

function fixedOrCustomMaterialBlock(material, choice) {
  const isCustom = choice.tier === PRICE_TIERS.CUSTOM;
  const materialLabel = t(MATERIAL_LABEL_KEYS[material.key]);
  return `
    <div class="tier-material" data-field-wrapper="pricing.${material.key}.tier">
      <p class="tier-material-title">${materialLabel} <span class="unit-hint">(${material.unit})</span></p>
      <div class="btn-group" data-group>
        <button type="button" class="btn-choice ${!isCustom ? "active" : ""}"
          data-field="pricing.${material.key}.tier" data-value="${PRICE_TIERS.STANDARD}">
          ${t("tierDefault")} <span class="price-hint">· ${material.defaultPrice} JOD</span>
        </button>
        <button type="button" class="btn-choice ${isCustom ? "active" : ""}"
          data-field="pricing.${material.key}.tier" data-value="${PRICE_TIERS.CUSTOM}">
          ${t("tierCustom")}
        </button>
      </div>
      ${
        isCustom
          ? `<input type="number" class="custom-price-input" dir="ltr"
              placeholder="${t("customPricePlaceholder")}"
              data-field="pricing.${material.key}.customPrice"
              data-type="number"
              value="${choice.customPrice ?? ""}" />`
          : ""
      }
      <span class="field-error" data-error-for="${material.key}"></span>
    </div>
  `;
}

export function renderStep3(state) {
  return `
    <h2 class="section-title">${t("section3Title")}</h2>
    <div class="step-content">
      <p class="hint-text">${t("pricingHintText1")}</p>

      ${TIER_MATERIALS.map((m) => tierMaterialBlock(m, state.pricing[m.key])).join("")}

      <p class="hint-text">${t("pricingHintText2")}</p>

      ${FIXED_OR_CUSTOM_MATERIALS.map((m) => fixedOrCustomMaterialBlock(m, state.pricing[m.key])).join("")}
    </div>
  `;
}

export function validateStep3(data) {
  const errors = {};
  const allKeys = [
    ...TIER_MATERIALS.map((m) => m.key),
    ...FIXED_OR_CUSTOM_MATERIALS.map((m) => m.key),
  ];
  allKeys.forEach((key) => {
    const choice = data.pricing[key];
    if (
      choice.tier === PRICE_TIERS.CUSTOM &&
      (choice.customPrice === "" || choice.customPrice == null || isNaN(choice.customPrice))
    ) {
      errors[key] = t("errRequired");
    }
  });
  return errors;
}
