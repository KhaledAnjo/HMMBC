// =====================================================================
// wizardController.js
// المتحكم الرئيسي بالـ Wizard: يدير الحالة (state)، التنقل بين الخطوات،
// التحقق (validation)، والربط مع محرك الحساب. هذا بديل Vanilla JS
// لمكوّن WizardContainer اللي كان مبني بـ React.
// =====================================================================

import { renderProgress } from "./wizardProgress.js";
import { renderStep1, validateStep1 } from "./step1.js";
import { renderStep2, validateStep2 } from "./step2.js";
import { renderStep3, validateStep3 } from "./step3.js";
import { renderStep4 } from "./step4.js";
import { bindFormEvents, renderErrors } from "./domBinding.js";
import { PRICE_TIERS } from "../constants/index.js";
import { calculateAll } from "../utils/calculationEngine.js";

// القيم الابتدائية لكل حقول الـ Wizard
function createInitialState() {
  return {
    // خطوة 1
    buildingType: "multi",
    numFloors: "",
    floorAreaSqm: "",
    ceilingHeight: 3,
    actualPerimeterM: "",
    apartmentsPerFloor: "",
    roomsPerApartment: "",
    bathroomsPerApartment: "",
    bathroomAreaSqm: "",
    bathroomType: "shower",
    kitchenAreaSqm: "",

    // خطوة 2
    roofType: "empty",
    hasElevator: false,
    hasRoofGarden: false,
    landCategory: "unknown",
    landAreaSqm: "",

    // خطوة 3
    pricing: {
      floorTilePerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      interiorPaintPerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      exteriorPaintPerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      facadeStonePerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      steelPerKg: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      cementPerBag: { tier: PRICE_TIERS.STANDARD, customPrice: null },
    },
  };
}

const STEP_RENDERERS = { 1: renderStep1, 2: renderStep2, 3: renderStep3, 4: renderStep4 };
const STEP_VALIDATORS = { 1: validateStep1, 2: validateStep2, 3: validateStep3 };

/**
 * يشغّل الـ Wizard جوا عنصر معين من الصفحة.
 *
 * @param {HTMLElement} rootEl - العنصر اللي رح يترسم فيه الـ Wizard كامل
 * @param {(report: object, rawInput: object) => void} onComplete - يُستدعى بعد نجاح الحساب
 */
export function runWizard(rootEl, onComplete) {
  const state = createInitialState();
  let currentStep = 1;
  let currentErrors = {};

  rootEl.innerHTML = `
    <div class="wizard-wrapper">
      <div id="wizard-progress"></div>
      <div class="wizard-card" id="wizard-step-container"></div>
      <div class="wizard-nav" id="wizard-nav"></div>
    </div>
  `;

  const progressEl = rootEl.querySelector("#wizard-progress");
  const stepContainerEl = rootEl.querySelector("#wizard-step-container");
  const navEl = rootEl.querySelector("#wizard-nav");

  function renderCurrentStep() {
    progressEl.innerHTML = renderProgress(currentStep);
    stepContainerEl.innerHTML = STEP_RENDERERS[currentStep](state);
    renderErrors(stepContainerEl, currentErrors);
    renderNav();

    bindFormEvents(stepContainerEl, state, {
      // كتابة برقم/نص: لا داعي لإعادة رسم الخطوة (نتجنب فقدان تركيز المؤشر)
      onInputChange: () => {},
      // اختيار (زر/مفتاح): نعيد رسم الخطوة لتحديث الحقول المشروطة (مثل سعر مخصص)
      onChoiceChange: () => renderCurrentStep(),
    });

    if (currentStep === 4) {
      const calcBtn = stepContainerEl.querySelector("#calculate-btn");
      calcBtn?.addEventListener("click", handleCalculate);
    }
  }

  function renderNav() {
    if (currentStep < 4) {
      navEl.innerHTML = `
        <button type="button" id="btn-back" class="btn-outline" ${currentStep === 1 ? "disabled" : ""}>السابق</button>
        <button type="button" id="btn-next" class="btn-primary">التالي</button>
      `;
      navEl.querySelector("#btn-back").addEventListener("click", goBack);
      navEl.querySelector("#btn-next").addEventListener("click", goNext);
    } else {
      navEl.innerHTML = `
        <button type="button" id="btn-back" class="btn-outline">السابق</button>
      `;
      navEl.querySelector("#btn-back").addEventListener("click", goBack);
    }
  }

  function validateCurrentStep() {
    const validator = STEP_VALIDATORS[currentStep];
    currentErrors = validator ? validator(state) : {};
    return Object.keys(currentErrors).length === 0;
  }

  function goNext() {
    if (!validateCurrentStep()) {
      renderErrors(stepContainerEl, currentErrors);
      return;
    }
    currentStep = Math.min(currentStep + 1, 4);
    currentErrors = {};
    renderCurrentStep();
  }

  function goBack() {
    currentErrors = {};
    currentStep = Math.max(currentStep - 1, 1);
    renderCurrentStep();
  }

  function handleCalculate() {
    const step3Errors = validateStep3(state);
    if (Object.keys(step3Errors).length > 0) {
      currentStep = 3;
      currentErrors = step3Errors;
      renderCurrentStep();
      return;
    }
    const report = calculateAll(state);
    onComplete(report, state);
  }

  renderCurrentStep();
}
