// =====================================================================
// section2.js
// القسم 2: المعلومات الداخلية (لكل شقة/وحدة)
// - كل مساحة تُدخل بطريقتين: مساحة مباشرة (م²) أو طول × عرض
// - متوسط مساحة غرفة النوم (لفحص تجاوز المساحة)
// =====================================================================

import { numberField, toggleField } from "./fieldTemplates.js";
import { t } from "../i18n.js";
import { getEffectiveAreas } from "./engineAdapter.js";

/**
 * حقل مساحة ثنائي الوضع: زرّا تبديل (م² / طول×عرض) + الحقول المناسبة.
 * modeField قيمته "area" أو "dims" — تبديله يعيد رسم القسم تلقائياً
 * (عبر onChoiceChange بالـ scrollWizard).
 */
function dualAreaField(label, cfg, state, errorKey) {
  const mode = state[cfg.modeField] || "area";
  const computed =
    mode === "dims"
      ? ((Number(state[cfg.lField]) || 0) * (Number(state[cfg.wField]) || 0)).toFixed(1)
      : null;

  return `
    <div class="field-group" data-field-wrapper="${errorKey}">
      <label>${label}<span class="required">*</span></label>
      <div class="btn-group" data-group>
        <button type="button" class="btn-choice ${mode === "area" ? "active" : ""}"
          data-field="${cfg.modeField}" data-value="area">${t("modeArea")}</button>
        <button type="button" class="btn-choice ${mode === "dims" ? "active" : ""}"
          data-field="${cfg.modeField}" data-value="dims">${t("modeDims")}</button>
      </div>
      ${
        mode === "area"
          ? `<input type="number" data-field="${cfg.areaField}" data-type="number"
              value="${state[cfg.areaField] ?? ""}" min="0" step="0.5"
              placeholder="${t("modeArea")}" />`
          : `<div class="grid-2">
              <input type="number" data-field="${cfg.lField}" data-type="number"
                value="${state[cfg.lField] ?? ""}" min="0" step="0.1"
                placeholder="${t("lengthLabel")} (m)" />
              <input type="number" data-field="${cfg.wField}" data-type="number"
                value="${state[cfg.wField] ?? ""}" min="0" step="0.1"
                placeholder="${t("widthLabel")} (m)" />
            </div>
            ${computed > 0 ? `<span class="unit-hint">= ${computed} m²</span>` : ""}`
      }
      <span class="field-error" data-error-for="${errorKey}"></span>
    </div>
  `;
}

const LIVING_CFG = { modeField: "livingAreaMode", areaField: "livingAreaPerApartment", lField: "livingAreaL", wField: "livingAreaW" };
const REG_BATH_CFG = { modeField: "regBathMode", areaField: "regularBathroomAreaSqm", lField: "regBathL", wField: "regBathW" };
const MASTER_BATH_CFG = { modeField: "masterBathMode", areaField: "masterBathroomAreaSqm", lField: "masterBathL", wField: "masterBathW" };
const KITCHEN_CFG = { modeField: "kitchenMode", areaField: "kitchenAreaSqm", lField: "kitchenLengthM", wField: "kitchenWidthM" };

export function renderSection2(state) {
  const hasMaster = Number(state.masterBathroomsPerApartment) > 0;

  return `
    <h2 class="section-title">${t("section2Title")}</h2>
    <p class="hint-text">${t("section2HintText")}</p>
    <div class="step-content">
      <div class="grid-2">
        ${numberField("bedroomsPerApartment", t("bedroomsLabel"), state.bedroomsPerApartment, { min: 1 })}
        ${numberField("avgBedroomAreaSqm", t("avgBedroomAreaLabel"), state.avgBedroomAreaSqm, { min: 1, step: 0.5, unit: "m²" })}
      </div>

      ${dualAreaField(t("livingAreaLabel"), LIVING_CFG, state, "livingArea")}

      <div class="grid-2">
        ${numberField("regularBathroomsPerApartment", t("regularBathroomsLabel"), state.regularBathroomsPerApartment, { min: 0 })}
        ${numberField("masterBathroomsPerApartment", t("masterBathroomsLabel"), state.masterBathroomsPerApartment, { min: 0, required: false })}
      </div>
      ${dualAreaField(t("regularBathroomAreaLabel"), REG_BATH_CFG, state, "regBathArea")}
      ${hasMaster ? dualAreaField(t("masterBathroomAreaLabel"), MASTER_BATH_CFG, state, "masterBathArea") : ""}

      ${dualAreaField(t("kitchenAreaLabel"), KITCHEN_CFG, state, "kitchenArea")}

      ${numberField("balconiesPerApartment", t("balconiesLabel"), state.balconiesPerApartment, { min: 0, required: false })}

      <div class="grid-2">
        ${toggleField("hasElevator", t("hasElevatorLabel"), state.hasElevator)}
        ${toggleField("hasRoofGarden", t("hasRoofGardenLabel"), state.hasRoofGarden)}
      </div>

      ${state.buildingType === "villa" ? poolBlock(state) : ""}
    </div>
  `;
}

/**
 * بلوك المسبح — فيلا فقط.
 * بيدعم وضعين للعمق:
 *  - uniform: عمق ثابت
 *  - sloped: عمق متدرّج (ضحل → عميق) — الأرضية بتصير مائلة،
 *    فحجم الماء ومساحة الأرضية والمضخة بتتغير جوهرياً.
 */
function poolBlock(state) {
  const depthMode = state.poolDepthMode || "uniform";
  return `
    <div class="pool-block">
      ${toggleField("hasPool", `🏊 ${t("hasPoolLabel")}`, state.hasPool)}
      ${
        !state.hasPool
          ? ""
          : `
        <div class="grid-2">
          ${numberField("poolLengthM", t("poolLength"), state.poolLengthM, { min: 1, step: 0.1, unit: "m" })}
          ${numberField("poolWidthM", t("poolWidth"), state.poolWidthM, { min: 1, step: 0.1, unit: "m" })}
        </div>

        <div class="field-group" data-field-wrapper="poolDepthMode">
          <label>${t("poolDepthModeLabel")}</label>
          <div class="btn-group" data-group>
            <button type="button" class="btn-choice ${depthMode === "uniform" ? "active" : ""}"
              data-field="poolDepthMode" data-value="uniform">${t("poolDepthUniform")}</button>
            <button type="button" class="btn-choice ${depthMode === "sloped" ? "active" : ""}"
              data-field="poolDepthMode" data-value="sloped">${t("poolDepthSloped")}</button>
          </div>
        </div>

        <div class="grid-2">
          ${numberField("poolShallowDepthM",
            depthMode === "sloped" ? t("poolShallowDepth") : t("poolDepth"),
            state.poolShallowDepthM, { min: 0.5, step: 0.1, unit: "m" })}
          ${
            depthMode === "sloped"
              ? numberField("poolDeepDepthM", t("poolDeepDepth"), state.poolDeepDepthM, { min: 0.5, step: 0.1, unit: "m" })
              : ""
          }
        </div>

        ${toggleField("hasPoolHeater", t("poolHeaterLabel"), state.hasPoolHeater)}
        <p class="hint-text">${t("poolHintText")}</p>`
      }
    </div>
  `;
}

export function validateSection2(data) {
  const errors = {};
  const reg = Number(data.regularBathroomsPerApartment);
  const master = Number(data.masterBathroomsPerApartment) || 0;
  const areas = getEffectiveAreas(data);

  if (!data.bedroomsPerApartment || data.bedroomsPerApartment < 1)
    errors.bedroomsPerApartment = t("errRequired");
  if (!data.avgBedroomAreaSqm || data.avgBedroomAreaSqm <= 0)
    errors.avgBedroomAreaSqm = t("errRequired");
  if (areas.livingArea <= 0) errors.livingArea = t("errRequired");

  if ((isNaN(reg) || reg < 0) || reg + master < 1)
    errors.regularBathroomsPerApartment = t("errAtLeastOneBathroom");
  if (reg > 0 && areas.regBathArea <= 0) errors.regBathArea = t("errRequired");
  if (master > 0 && areas.masterBathArea <= 0) errors.masterBathArea = t("errRequired");

  if (areas.kitchenArea <= 0) errors.kitchenArea = t("errRequired");

  // المسبح (فيلا فقط، وفقط إذا مفعّل)
  if (data.buildingType === "villa" && data.hasPool) {
    if (!data.poolLengthM || data.poolLengthM <= 0) errors.poolLengthM = t("errRequired");
    if (!data.poolWidthM || data.poolWidthM <= 0) errors.poolWidthM = t("errRequired");
    if (!data.poolShallowDepthM || data.poolShallowDepthM <= 0) errors.poolShallowDepthM = t("errRequired");
    if (data.poolDepthMode === "sloped") {
      if (!data.poolDeepDepthM || data.poolDeepDepthM <= 0) {
        errors.poolDeepDepthM = t("errRequired");
      } else if (Number(data.poolDeepDepthM) < Number(data.poolShallowDepthM)) {
        errors.poolDeepDepthM = t("errPoolDepthOrder");
      }
    }
  }

  return errors;
}
