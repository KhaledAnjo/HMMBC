// =====================================================================
// section4.js
// القسم 4: مراجعة كل المدخلات + زر الحساب النهائي
// =====================================================================

import { TIER_MATERIALS, FIXED_OR_CUSTOM_MATERIALS } from "./wizardOptions.js";
import { PRICE_TIERS } from "../constants/index.js";
import { t } from "../i18n.js";
import { getEffectiveAreas } from "./engineAdapter.js";

const MATERIAL_LABEL_KEYS = {
  floorTilePerSqm: "materialFloorTile",
  interiorPaintPerSqm: "materialInteriorPaint",
  facadeStonePerSqm: "materialFacadeStone",
  windowsPerSqm: "materialWindows",
  railingPerMeter: "materialRailing",
  mainDoorPerUnit: "materialMainDoor",
  steelPerKg: "materialSteel",
  cementPerBag: "materialCement",
};

const BUILDING_TYPE_LABEL_KEYS = {
  floorAddition: "cardFloorAdditionTitle",
  villa: "cardVillaTitle",
  fullBuilding: "cardFullBuildingTitle",
};

function reviewRow(label, value) {
  return `
    <div class="review-row">
      <span class="review-label">${label}</span>
      <span class="review-value">${value}</span>
    </div>
  `;
}

function reviewSection(title, rowsHtml) {
  return `<div class="review-section"><h3>${title}</h3>${rowsHtml}</div>`;
}

function tierLabel(choice) {
  if (choice.tier === PRICE_TIERS.CUSTOM) return `${t("tierCustom")} — ${choice.customPrice ?? "—"} JOD`;
  const map = {
    [PRICE_TIERS.ECONOMY]: t("tierEconomy"),
    [PRICE_TIERS.STANDARD]: t("tierStandard"),
    [PRICE_TIERS.PREMIUM]: t("tierPremium"),
  };
  return map[choice.tier] ?? "—";
}

export function renderSection4(state) {
  const isVilla = state.buildingType === "villa";
  const areas = getEffectiveAreas(state);

  const specsRows = [
    reviewRow(t("reviewBuildingType"), t(BUILDING_TYPE_LABEL_KEYS[state.buildingType]) ?? state.buildingType),
    reviewRow(state.buildingType === "floorAddition" ? t("numAddedFloorsLabel") : t("reviewNumFloors"), state.numFloors),
    state.buildingType === "floorAddition"
      ? reviewRow(t("existingFloorsLabel"), state.existingFloors || "—")
      : "",
    reviewRow(t("reviewFloorArea"), `${state.floorAreaSqm} m²`),
    reviewRow(t("reviewCeilingHeight"), `${state.ceilingHeight} m`),
    reviewRow(t("reviewPerimeter"), state.actualPerimeterM ? `${state.actualPerimeterM} ${t("reviewPerimeterActual")}` : t("reviewPerimeterEstimated")),
    isVilla ? "" : reviewRow(t("reviewNumApartments"), state.numApartments),
    reviewRow(t("reviewLandArea"), state.landAreaSqm ? `${state.landAreaSqm} m²` : t("reviewLandAreaNotSet")),
    state.buildingType === "fullBuilding"
      ? reviewRow(
          t("reviewGarage"),
          `${state.garageLocation === "ground" ? t("garageGround") : t("garageBasement")} — ${
            state.garageAreaMode === "custom" ? state.garageAreaSqm || 0 : state.floorAreaSqm || 0
          } m² — ${state.garageHeightM || 0} m`
        )
      : "",
  ].join("");

  const poolRows =
    isVilla && state.hasPool
      ? [
          reviewRow(t("reviewPoolDims"), `${state.poolLengthM || 0} × ${state.poolWidthM || 0} m`),
          reviewRow(
            t("reviewPoolDepth"),
            state.poolDepthMode === "sloped"
              ? `${state.poolShallowDepthM || 0} → ${state.poolDeepDepthM || 0} m (${t("poolDepthSloped")})`
              : `${state.poolShallowDepthM || 0} m (${t("poolDepthUniform")})`
          ),
          reviewRow(t("poolHeaterLabel"), state.hasPoolHeater ? t("yes") : t("no")),
        ].join("")
      : "";

  const interiorRows = [
    reviewRow(t("reviewBedrooms"), `${state.bedroomsPerApartment} × ${state.avgBedroomAreaSqm || 0} m²`),
    reviewRow(t("reviewLivingArea"), `${areas.livingArea.toFixed(1)} m²`),
    reviewRow(t("reviewRegularBathrooms"), `${state.regularBathroomsPerApartment || 0} × ${areas.regBathArea.toFixed(1)} m²`),
    reviewRow(t("reviewMasterBathrooms"), `${state.masterBathroomsPerApartment || 0}${Number(state.masterBathroomsPerApartment) > 0 ? ` × ${areas.masterBathArea.toFixed(1)} m²` : ""}`),
    reviewRow(t("reviewKitchen"), `${areas.kitchenArea.toFixed(1)} m²`),
    reviewRow(t("reviewBalconies"), state.balconiesPerApartment || "0"),
    reviewRow(t("reviewElevator"), state.hasElevator ? t("yes") : t("no")),
    reviewRow(t("reviewRoofGarden"), state.hasRoofGarden ? t("yes") : t("no")),
  ].join("");

  const pricingRows = [
    ...TIER_MATERIALS.map((m) => reviewRow(t(MATERIAL_LABEL_KEYS[m.key]), tierLabel(state.pricing[m.key]))),
    ...FIXED_OR_CUSTOM_MATERIALS.map((m) =>
      reviewRow(
        t(MATERIAL_LABEL_KEYS[m.key]),
        state.pricing[m.key].tier === PRICE_TIERS.CUSTOM
          ? `${t("tierCustom")} — ${state.pricing[m.key].customPrice ?? "—"} JOD`
          : `${t("tierDefault")} — ${m.defaultPrice} JOD`
      )
    ),
  ].join("");

  return `
    <h2 class="section-title">${t("section4Title")}</h2>
    <div class="step-content">
      ${reviewSection(t("reviewSpecsTitle"), specsRows)}
      ${reviewSection(t("reviewInteriorTitle"), interiorRows)}
      ${poolRows ? reviewSection(t("catPool"), poolRows) : ""}
      ${reviewSection(t("reviewPricingTitle"), pricingRows)}
      <button type="button" id="calculate-btn" class="btn-primary btn-full">
        ${t("btnCalculate")}
      </button>
    </div>
  `;
}
