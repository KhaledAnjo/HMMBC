// =====================================================================
// step2.js
// الخطوة 2: خيارات إضافية (سقف، مصعد، فئة تنظيم الأرض...)
// =====================================================================

import { numberField, selectField, toggleField } from "./fieldTemplates.js";
import { ROOF_TYPE_OPTIONS, LAND_CATEGORY_OPTIONS } from "./wizardOptions.js";

export function renderStep2(state) {
  return `
    <div class="step-content">
      ${selectField("roofType", "نوع السقف", state.roofType, ROOF_TYPE_OPTIONS)}

      <div class="grid-2">
        ${toggleField("hasElevator", "يوجد مصعد؟", state.hasElevator)}
        ${toggleField("hasRoofGarden", "يوجد حديقة سطح؟", state.hasRoofGarden)}
      </div>

      <p class="hint-text">
        هذي المعلومات تُستخدم لاحقاً في التحقق من مطابقة تصميمك لمعايير
        أمانة عمان 2018 — إذا ما تعرف فئة تنظيم أرضك، اختر "لا أعرف".
      </p>

      <div class="grid-2">
        ${selectField("landCategory", "فئة تنظيم الأرض", state.landCategory, LAND_CATEGORY_OPTIONS, { required: false })}
        ${numberField("landAreaSqm", "مساحة قطعة الأرض", state.landAreaSqm, { min: 0, unit: "م² — اختياري", required: false })}
      </div>
    </div>
  `;
}

export function validateStep2(data) {
  const errors = {};
  if (!data.roofType) errors.roofType = "اختر نوع السقف";
  if (
    data.landCategory !== "unknown" &&
    data.landAreaSqm !== "" &&
    data.landAreaSqm != null &&
    data.landAreaSqm <= 0
  ) {
    errors.landAreaSqm = "مساحة الأرض يجب أن تكون أكبر من صفر";
  }
  return errors;
}
