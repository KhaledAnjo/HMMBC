// =====================================================================
// step1.js
// الخطوة 1: نوع المبنى + المواصفات الأساسية
// =====================================================================

import { numberField, selectField, buttonGroupField } from "./fieldTemplates.js";
import { BUILDING_TYPE_OPTIONS, BATHROOM_TYPE_OPTIONS } from "./wizardOptions.js";

export function renderStep1(state) {
  const isVilla = state.buildingType === "villa";

  return `
    <div class="step-content">
      ${buttonGroupField("buildingType", "نوع المبنى", state.buildingType, BUILDING_TYPE_OPTIONS)}

      <div class="grid-2">
        ${numberField("numFloors", "عدد الطوابق", state.numFloors, { min: 1 })}
        ${numberField("floorAreaSqm", "مساحة الطابق", state.floorAreaSqm, { min: 1, unit: "م²" })}
        ${numberField("ceilingHeight", "ارتفاع السقف", state.ceilingHeight, { min: 2.4, step: 0.1, unit: "م" })}
        ${numberField("actualPerimeterM", "محيط المبنى الفعلي (إن وجد)", state.actualPerimeterM, {
          min: 0,
          step: 0.1,
          unit: "م — اختياري",
          required: false,
          placeholder: "اتركه فارغاً لتقدير تلقائي",
        })}
      </div>

      <p class="hint-text">
        محيط المبنى يُستخدم لحساب مساحة الجدران الخارجية (بلوك، دهان خارجي،
        حجر واجهة). إذا ما أدخلته، رح نقدّره تلقائياً بافتراض مسقط مربّع
        تقريباً.
      </p>

      <div class="grid-2">
        ${numberField("apartmentsPerFloor", "عدد الشقق في الطابق", state.apartmentsPerFloor, { min: 1 })}
        ${numberField("roomsPerApartment", "عدد الغرف في الشقة", state.roomsPerApartment, { min: 1 })}
        ${numberField("bathroomsPerApartment", "عدد الحمامات في الشقة", state.bathroomsPerApartment, { min: 1 })}
        ${numberField("bathroomAreaSqm", "مساحة الحمام الواحد", state.bathroomAreaSqm, { min: 1, step: 0.5, unit: "م²" })}
        ${selectField("bathroomType", "نوع الحمام", state.bathroomType, BATHROOM_TYPE_OPTIONS)}
        ${numberField("kitchenAreaSqm", "مساحة المطبخ", state.kitchenAreaSqm, { min: 1, step: 0.5, unit: "م²" })}
      </div>

      ${
        isVilla
          ? `<div class="notice-box">
              اخترت "فيلا" — رح تظهر لك لاحقاً صفحة منفصلة لحساب المسبح
              (اختيارية) بعد إتمام خطوات الـ Wizard.
            </div>`
          : ""
      }
    </div>
  `;
}

/**
 * يتحقق من صحة بيانات الخطوة 1 ويرجع كائن بالأخطاء (فارغ = لا يوجد أخطاء)
 */
export function validateStep1(data) {
  const errors = {};
  if (!data.buildingType) errors.buildingType = "اختر نوع المبنى";
  if (!data.numFloors || data.numFloors < 1)
    errors.numFloors = "عدد الطوابق يجب أن يكون 1 على الأقل";
  if (!data.floorAreaSqm || data.floorAreaSqm <= 0)
    errors.floorAreaSqm = "أدخل مساحة الطابق";
  if (!data.ceilingHeight || data.ceilingHeight <= 0)
    errors.ceilingHeight = "أدخل ارتفاع السقف";
  if (!data.apartmentsPerFloor || data.apartmentsPerFloor < 1)
    errors.apartmentsPerFloor = "عدد الشقق يجب أن يكون 1 على الأقل";
  if (!data.roomsPerApartment || data.roomsPerApartment < 1)
    errors.roomsPerApartment = "أدخل عدد الغرف";
  if (!data.bathroomsPerApartment || data.bathroomsPerApartment < 1)
    errors.bathroomsPerApartment = "أدخل عدد الحمامات";
  if (!data.bathroomAreaSqm || data.bathroomAreaSqm <= 0)
    errors.bathroomAreaSqm = "أدخل مساحة الحمام";
  if (!data.kitchenAreaSqm || data.kitchenAreaSqm <= 0)
    errors.kitchenAreaSqm = "أدخل مساحة المطبخ";
  if (
    data.actualPerimeterM !== "" &&
    data.actualPerimeterM != null &&
    data.actualPerimeterM <= 0
  ) {
    errors.actualPerimeterM = "المحيط يجب أن يكون أكبر من صفر";
  }
  return errors;
}
