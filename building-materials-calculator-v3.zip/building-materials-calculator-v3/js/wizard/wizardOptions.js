// =====================================================================
// wizardOptions.js
// خيارات المواد المستخدمة بقسم الأسعار (3) وقسم المراجعة (4)
// =====================================================================

// المواد ذات المستويات (اقتصادي/متوسط/فاخر)
export const TIER_MATERIALS = [
  { key: "floorTilePerSqm", labelAr: "بلاط", unit: "م²" },
  { key: "interiorPaintPerSqm", labelAr: "دهان داخلي", unit: "م²" },
  { key: "facadeStonePerSqm", labelAr: "حجر واجهة", unit: "م²" },
  { key: "windowsPerSqm", labelAr: "شبابيك ألمنيوم/UPVC", unit: "م²" },
  { key: "railingPerMeter", labelAr: "درابزين درج", unit: "م" },
  { key: "mainDoorPerUnit", labelAr: "باب رئيسي معدني", unit: "عدد" },
];

// المواد ذات السعر الثابت الواحد (قابل للتخصيص)
export const FIXED_OR_CUSTOM_MATERIALS = [
  { key: "steelPerKg", labelAr: "حديد تسليح", unit: "كغ", defaultPrice: 0.52 },
  { key: "cementPerBag", labelAr: "أسمنت", unit: "كيس", defaultPrice: 4.25 },
];
