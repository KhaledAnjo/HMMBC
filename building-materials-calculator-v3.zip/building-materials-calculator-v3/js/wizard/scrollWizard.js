// =====================================================================
// scrollWizard.js
// المتحكم بأسلوب Scroll-Reveal + Auto-Save + شريط أدوات المشروع
// إضافات هذه النسخة:
// - مؤشر تقدم لاصق أعلى الصفحة (1→2→3→4)
// - زر ✏️ "تعديل" على الأقسام المقفلة (يفتح القسم ويلغي ما بعده)
// - أنيميشن نجاح (checkmark) عند "تم"
// - صفحة إعدادات الأسعار الكاملة (كل الأسعار الثابتة + تاريخ التحديث)
// =====================================================================

import { bindFormEvents, renderErrors } from "./domBinding.js";
import { renderSection1, validateSection1 } from "./section1.js";
import { renderSection2, validateSection2 } from "./section2.js";
import { renderStep3 as renderSection3, validateStep3 as validateSection3 } from "./step3.js";
import { renderSection4 } from "./section4.js";
import { toggleContractorsDirectory } from "./contractorsDirectory.js";
import { mapStateToEngineInput, checkAreaOverflow } from "./engineAdapter.js";
import { renderResults } from "./results.js";
import { PRICE_TIERS, FIXED_PRICES, FIXED_PRICE_LABELS, PRICES_LAST_UPDATED } from "../constants/index.js";
import { calculateAll } from "../utils/calculationEngine.js";
import {
  loadPriceOverrides,
  savePriceOverrides,
  clearPriceOverrides,
  getEffectiveFixedPrices,
} from "../utils/priceSettings.js";
import { t, tf, getCurrentLang } from "../i18n.js";
import {
  saveProjectState,
  clearProjectState,
  exportProjectToFile,
  importProjectFromFile,
} from "../projectStorage.js";

function createDefaultState(buildingType) {
  return {
    buildingType,
    // قسم 1
    numFloors: "",
    existingFloors: "",   // لتكملة الطابق فقط: طوابق المبنى القائم
    floorAreaSqm: "",
    ceilingHeight: 3,
    actualPerimeterM: "",
    numApartments: "",
    landCategory: "unknown",
    landAreaSqm: "",

    // الكراج (مبنى كامل فقط) — طابق مستقل خارج عدد الطوابق السكنية
    garageLocation: "basement",   // basement | ground
    garageAreaMode: "full",       // full (= مساحة الطابق) | custom
    garageAreaSqm: "",
    garageHeightM: 3,

    // قسم 2
    bedroomsPerApartment: "",
    avgBedroomAreaSqm: "",
    livingAreaMode: "area",
    livingAreaPerApartment: "",
    livingAreaL: "",
    livingAreaW: "",
    regularBathroomsPerApartment: "",
    regBathMode: "area",
    regularBathroomAreaSqm: "",
    regBathL: "",
    regBathW: "",
    masterBathroomsPerApartment: "",
    masterBathMode: "area",
    masterBathroomAreaSqm: "",
    masterBathL: "",
    masterBathW: "",
    kitchenMode: "dims",
    kitchenAreaSqm: "",
    kitchenLengthM: "",
    kitchenWidthM: "",
    balconiesPerApartment: "",
    hasElevator: false,
    hasRoofGarden: false,

    // المسبح (فيلا فقط)
    hasPool: false,
    poolLengthM: "",
    poolWidthM: "",
    poolDepthMode: "uniform",     // uniform | sloped
    poolShallowDepthM: "",
    poolDeepDepthM: "",
    hasPoolHeater: false,

    // قسم 3 (الأسعار)
    pricing: {
      floorTilePerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      interiorPaintPerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      facadeStonePerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      windowsPerSqm: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      railingPerMeter: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      mainDoorPerUnit: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      steelPerKg: { tier: PRICE_TIERS.STANDARD, customPrice: null },
      cementPerBag: { tier: PRICE_TIERS.STANDARD, customPrice: null },
    },
  };
}

/** يدمج مشروع محفوظ (لو موجود) فوق القيم الافتراضية */
function createInitialState(buildingType, savedState) {
  const defaults = createDefaultState(buildingType);
  if (!savedState) return defaults;
  return {
    ...defaults,
    ...savedState,
    pricing: { ...defaults.pricing, ...(savedState.pricing || {}) },
  };
}

// ---------------------------------------------------------------------
// مؤشر التقدم اللاصق (1→2→3→4)
// ---------------------------------------------------------------------

function mountProgressIndicator(rootEl) {
  const stepsKeys = ["progressStep1", "progressStep2", "progressStep3", "progressStep4"];
  const html = `
    <div class="progress-indicator" id="progress-indicator">
      ${stepsKeys
        .map(
          (key, i) => `
        <div class="progress-step" data-step="${i + 1}">
          <span class="progress-dot">${i + 1}</span>
          <span class="progress-label">${t(key)}</span>
        </div>
        ${i < 3 ? '<span class="progress-line"></span>' : ""}`
        )
        .join("")}
    </div>
  `;
  rootEl.insertAdjacentHTML("beforeend", html);
}

/** يحدّث حالة المؤشر بمسح الأقسام الموجودة بالصفحة */
function updateProgressIndicator() {
  const indicator = document.getElementById("progress-indicator");
  if (!indicator) return;
  for (let i = 1; i <= 4; i++) {
    const stepEl = indicator.querySelector(`.progress-step[data-step="${i}"]`);
    const sectionEl = document.getElementById(`section-${i}`);
    stepEl.classList.remove("completed", "current");
    if (!sectionEl) continue;
    if (sectionEl.classList.contains("section-locked")) {
      stepEl.classList.add("completed");
      stepEl.querySelector(".progress-dot").innerHTML = "✓";
    } else {
      stepEl.classList.add("current");
      stepEl.querySelector(".progress-dot").textContent = String(i);
    }
  }
}

// ---------------------------------------------------------------------
// إزالة الأقسام اللاحقة + النتائج (تُستخدم عند "تعديل" قسم مقفول)
// ---------------------------------------------------------------------

function removeSectionsAfter(id) {
  for (let i = id + 1; i <= 4; i++) {
    document.getElementById(`section-${i}`)?.remove();
  }
  const resultsRootEl = document.getElementById("results-root");
  if (resultsRootEl) {
    resultsRootEl.innerHTML = "";
    resultsRootEl.classList.add("hidden");
  }
}

// ---------------------------------------------------------------------
// أقسام الفورم (1–3)
// ---------------------------------------------------------------------

function mountSection(parentEl, { id, renderFn, validateFn, state, onDone }) {
  // حماية من التكرار (لو القسم موجود أصلاً ما منركّبه مرة تانية)
  if (document.getElementById(`section-${id}`)) return;

  const sectionHtml = `
    <section class="wizard-section" id="section-${id}" data-section="${id}">
      <div class="section-body">${renderFn(state)}</div>
      <button type="button" class="btn-primary btn-done" id="done-section-${id}">${t("btnDone")}</button>
      <div class="field-error" id="section-${id}-error"></div>
    </section>
  `;
  parentEl.insertAdjacentHTML("beforeend", sectionHtml);
  const sectionEl = document.getElementById(`section-${id}`);

  function rerender() {
    sectionEl.innerHTML = `
      <div class="section-body">${renderFn(state)}</div>
      <button type="button" class="btn-primary btn-done" id="done-section-${id}">${t("btnDone")}</button>
      <div class="field-error" id="section-${id}-error"></div>
    `;
    // ملاحظة: innerHTML يمسح المحتوى بس الـ listeners مربوطة على sectionEl
    // نفسه (event delegation) فبتضل شغالة — bindFormEvents بيحدّث الـ
    // callbacks فقط بدون إعادة ربط (إصلاح باغ التراكم)
    attachDoneButton();
    bindFormEvents(sectionEl, state, bindOptions);
  }

  const bindOptions = {
    onInputChange: (field) => {
      saveProjectState(state);
      if (field === "masterBathroomsPerApartment") rerender();
    },
    onChoiceChange: () => {
      rerender();
      saveProjectState(state);
    },
  };
  bindFormEvents(sectionEl, state, bindOptions);
  attachDoneButton();

  function lockSection() {
    sectionEl.classList.add("section-locked");
    const btn = sectionEl.querySelector(`#done-section-${id}`);
    btn.innerHTML = `
      <svg class="check-svg" viewBox="0 0 24 24" fill="none">
        <path d="M4 12.5l5.5 5.5L20 6.5" stroke="currentColor" stroke-width="3"
          stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <span>${t("btnDoneSuccess")}</span>
    `;
    btn.disabled = true;

    // زر ✏️ تعديل — يفتح القسم ويلغي كل الأقسام اللي بعده
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "btn-edit-section";
    editBtn.id = `edit-section-${id}`;
    editBtn.innerHTML = `✏️ ${t("btnEditSection")}`;
    editBtn.addEventListener("click", () => unlockSection());
    sectionEl.appendChild(editBtn);
  }

  function unlockSection() {
    if (!confirm(t("confirmEditSection"))) return;
    removeSectionsAfter(id);
    sectionEl.classList.remove("section-locked");
    sectionEl.querySelector(`#edit-section-${id}`)?.remove();
    const btn = sectionEl.querySelector(`#done-section-${id}`);
    btn.disabled = false;
    btn.textContent = t("btnDone");
    updateProgressIndicator();
    sectionEl.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function attachDoneButton() {
    const btn = sectionEl.querySelector(`#done-section-${id}`);
    btn.addEventListener("click", () => {
      const errors = validateFn(state);
      renderErrors(sectionEl, errors);
      if (Object.keys(errors).length > 0) return;

      // تنبيه تجاوز المساحة (غير مانع) — بمعامل صافي المساحة 85%
      if (id === 2) {
        const overflow = checkAreaOverflow(state);
        const existingWarn = sectionEl.querySelector(".area-overflow-warning");
        if (existingWarn) existingWarn.remove();
        if (overflow) {
          sectionEl.insertAdjacentHTML(
            "beforeend",
            `<div class="notice-box area-overflow-warning">${tf("areaOverflowWarning", overflow)}</div>`
          );
        }
      }

      lockSection();
      saveProjectState(state);
      updateProgressIndicator();
      onDone();
      updateProgressIndicator();
    });
  }

  return sectionEl;
}

// ---------------------------------------------------------------------
// القسم النهائي (مراجعة + حساب)
// ---------------------------------------------------------------------

function mountFinalSection(parentEl, { state, resultsRootEl }) {
  if (document.getElementById("section-4")) return;
  const sectionHtml = `
    <section class="wizard-section" id="section-4" data-section="4">
      ${renderSection4(state)}
    </section>
  `;
  parentEl.insertAdjacentHTML("beforeend", sectionHtml);
  const sectionEl = document.getElementById("section-4");

  const calcBtn = sectionEl.querySelector("#calculate-btn");
  calcBtn.addEventListener("click", () => {
    const pricingErrors = validateSection3(state);
    if (Object.keys(pricingErrors).length > 0) {
      alert(t("errRequired"));
      return;
    }
    saveProjectState(state);
    const engineInput = mapStateToEngineInput(state);
    const report = calculateAll(engineInput);
    renderResults(resultsRootEl, report, state);
  });
}

// ---------------------------------------------------------------------
// صفحة إعدادات الأسعار (كل الأسعار الثابتة قابلة للتعديل)
// ---------------------------------------------------------------------

function mountPriceSettingsPanel(rootEl) {
  const lang = getCurrentLang();
  const effective = getEffectiveFixedPrices();
  const overrides = loadPriceOverrides();

  const rows = Object.keys(FIXED_PRICES)
    .map((key) => {
      const label = FIXED_PRICE_LABELS[key]?.[lang] || key;
      const isModified = key in overrides;
      return `
        <div class="price-setting-row ${isModified ? "modified" : ""}">
          <label for="ps_${key}">${label}
            ${isModified ? `<span class="unit-hint">(${t("priceModifiedHint")})</span>` : ""}
          </label>
          <div class="price-setting-input">
            <input type="number" id="ps_${key}" data-price-key="${key}"
              value="${effective[key]}" min="0" step="0.01" dir="ltr" />
            <span class="unit-hint">JOD</span>
          </div>
        </div>`;
    })
    .join("");

  const panelHtml = `
    <div class="price-settings-panel" id="price-settings-panel">
      <div class="price-settings-header">
        <h3>${t("priceSettingsTitle")}</h3>
        <p class="hint-text">${tf("pricesLastUpdated", { date: PRICES_LAST_UPDATED })}</p>
        <p class="hint-text">${t("priceSettingsHint")}</p>
      </div>
      <div class="price-settings-grid">${rows}</div>
      <div class="price-settings-actions">
        <button type="button" id="ps-save" class="btn-primary">${t("btnSavePrices")}</button>
        <button type="button" id="ps-reset" class="btn-outline">${t("btnResetPrices")}</button>
        <button type="button" id="ps-close" class="btn-outline">${t("btnClosePrices")}</button>
      </div>
    </div>
  `;
  rootEl.querySelector(".project-toolbar").insertAdjacentHTML("afterend", panelHtml);
  const panel = document.getElementById("price-settings-panel");

  panel.querySelector("#ps-save").addEventListener("click", () => {
    const newOverrides = {};
    panel.querySelectorAll("[data-price-key]").forEach((input) => {
      const key = input.dataset.priceKey;
      const val = Number(input.value);
      if (!isNaN(val) && val >= 0 && val !== FIXED_PRICES[key]) {
        newOverrides[key] = val;
      }
    });
    savePriceOverrides(newOverrides);
    panel.remove();
    alert(t("pricesSavedMsg"));
  });

  panel.querySelector("#ps-reset").addEventListener("click", () => {
    if (!confirm(t("confirmResetPrices"))) return;
    clearPriceOverrides();
    panel.remove();
  });

  panel.querySelector("#ps-close").addEventListener("click", () => panel.remove());
  panel.scrollIntoView({ behavior: "smooth", block: "start" });
}

// ---------------------------------------------------------------------
// شريط الأدوات
// ---------------------------------------------------------------------

function mountToolbar(rootEl, state) {
  const toolbarHtml = `
    <div class="project-toolbar">
      <button type="button" id="btn-new-project" class="btn-outline">${t("btnNewProject")}</button>
      <button type="button" id="btn-save-project" class="btn-outline">${t("btnSaveProject")}</button>
      <button type="button" id="btn-open-project" class="btn-outline">${t("btnOpenProject")}</button>
      <button type="button" id="btn-price-settings" class="btn-outline">${t("btnPriceSettings")}</button>
      <button type="button" id="btn-contractors-directory" class="btn-outline">${t("btnContractorsDirectory")}</button>
      <input type="file" id="input-open-project" accept="application/json" class="hidden" />
    </div>
  `;
  rootEl.insertAdjacentHTML("beforeend", toolbarHtml);

  rootEl.querySelector("#btn-new-project").addEventListener("click", () => {
    if (!confirm(t("confirmNewProject"))) return;
    clearProjectState();
    location.reload();
  });

  rootEl.querySelector("#btn-save-project").addEventListener("click", () => {
    exportProjectToFile(state);
  });

  rootEl.querySelector("#btn-price-settings").addEventListener("click", () => {
    const existing = document.getElementById("price-settings-panel");
    if (existing) {
      existing.remove();
      return;
    }
    mountPriceSettingsPanel(rootEl);
  });

  rootEl.querySelector("#btn-contractors-directory").addEventListener("click", () => {
    toggleContractorsDirectory(rootEl);
  });

  const fileInput = rootEl.querySelector("#input-open-project");
  rootEl.querySelector("#btn-open-project").addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    importProjectFromFile(file, (parsedState) => {
      saveProjectState(parsedState);
      location.reload();
    });
  });
}

// ---------------------------------------------------------------------

export function runScrollWizard(rootEl, buildingType, savedState = null) {
  const state = createInitialState(buildingType, savedState);
  const resultsRootEl = document.getElementById("results-root");

  rootEl.innerHTML = "";
  resultsRootEl.innerHTML = "";
  resultsRootEl.classList.add("hidden");

  mountProgressIndicator(rootEl);
  mountToolbar(rootEl, state);

  mountSection(rootEl, {
    id: 1,
    renderFn: renderSection1,
    validateFn: validateSection1,
    state,
    onDone: () => {
      mountSection(rootEl, {
        id: 2,
        renderFn: renderSection2,
        validateFn: validateSection2,
        state,
        onDone: () => {
          mountSection(rootEl, {
            id: 3,
            renderFn: renderSection3,
            validateFn: validateSection3,
            state,
            onDone: () => {
              mountFinalSection(rootEl, { state, resultsRootEl });
              updateProgressIndicator();
              document.getElementById("section-4").scrollIntoView({ behavior: "smooth", block: "start" });
            },
          });
        },
      });
    },
  });

  updateProgressIndicator();
}
