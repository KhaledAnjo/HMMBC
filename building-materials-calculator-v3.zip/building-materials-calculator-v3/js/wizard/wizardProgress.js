// =====================================================================
// wizardProgress.js
// يبني HTML شريط تقدم الخطوات الأربع
// =====================================================================

const STEP_LABELS = ["نوع المبنى", "الخيارات", "الأسعار", "مراجعة وحساب"];

export function renderProgress(currentStep) {
  return `
    <div class="wizard-progress">
      ${STEP_LABELS.map((label, idx) => {
        const stepNumber = idx + 1;
        const isActive = stepNumber === currentStep;
        const isDone = stepNumber < currentStep;
        const stateClass = isDone ? "done" : isActive ? "active" : "";
        return `
          <div class="progress-step ${stateClass}">
            <div class="progress-circle">${isDone ? "✓" : stepNumber}</div>
            <span class="progress-label">${label}</span>
          </div>
          ${
            stepNumber < STEP_LABELS.length
              ? `<div class="progress-line ${isDone ? "done" : ""}"></div>`
              : ""
          }
        `;
      }).join("")}
    </div>
  `;
}
