// =====================================================================
// step4.js
// الخطوة 4: مراجعة كل المدخلات قبل الحساب النهائي
// =====================================================================

import {
  BUILDING_TYPE_OPTIONS,
  BATHROOM_TYPE_OPTIONS,
  ROOF_TYPE_OPTIONS,
  LAND_CATEGORY_OPTIONS,
  TIER_MATERIALS,
  FIXED_OR_CUSTOM_MATERIALS,
} from "./wizardOptions.js";
import { PRICE_TIERS } from "../constants/index.js";

function findLabel(options, value) {
  return options.find((o) => o.value === value)?.labelAr ?? value ?? "—";
}

function reviewRow(label, value) {
  return `
    <div class="review-row">
      <span class="review-label">${label}</span>
      <span class="review-value">${value}</span>
    </div>
  `;
}

function reviewSection(title, rowsHtml) {
  return `
    <div class="review-section">
      <h3>${title}</h3>
      ${rowsHtml}
    </div>
  `;
}

function tierLabel(choice) {
  if (choice.tier === PRICE_TIERS.CUSTOM) {
    return `مخصص — ${choice.customPrice ?? "—"} د.أ`;
  }
  const map = {
    [PRICE_TIERS.ECONOMY]: "اقتصادي",
    [PRICE_TIERS.STANDARD]: "متوسط",
    [PRICE_TIERS.PREMIUM]: "فاخر",
  };
  return map[choice.tier] ?? "—";
}

export function renderStep4(state) {
  const specsRows = [
    reviewRow("نوع المبنى", findLabel(BUILDING_TYPE_OPTIONS, state.buildingType)),
    reviewRow("عدد الطوابق", state.numFloors),
    reviewRow("مساحة الطابق", `${state.floorAreaSqm} م²`),
    reviewRow("ارتفاع السقف", `${state.ceilingHeight} م`),
    reviewRow(
      "محيط المبنى",
      state.actualPerimeterM ? `${state.actualPerimeterM} م (فعلي)` : "تقدير تلقائي"
    ),
    reviewRow("عدد الشقق في الطابق", state.apartmentsPerFloor),
    reviewRow("عدد الغرف في الشقة", state.roomsPerApartment),
    reviewRow("عدد الحمامات في الشقة", state.bathroomsPerApartment),
    reviewRow("مساحة الحمام", `${state.bathroomAreaSqm} م²`),
    reviewRow("نوع الحمام", findLabel(BATHROOM_TYPE_OPTIONS, state.bathroomType)),
    reviewRow("مساحة المطبخ", `${state.kitchenAreaSqm} م²`),
  ].join("");

  const optionsRows = [
    reviewRow("نوع السقف", findLabel(ROOF_TYPE_OPTIONS, state.roofType)),
    reviewRow("مصعد", state.hasElevator ? "نعم" : "لا"),
    reviewRow("حديقة سطح", state.hasRoofGarden ? "نعم" : "لا"),
    reviewRow("فئة تنظيم الأرض", findLabel(LAND_CATEGORY_OPTIONS, state.landCategory)),
    reviewRow("مساحة الأرض", state.landAreaSqm ? `${state.landAreaSqm} م²` : "غير محدد"),
  ].join("");

  const pricingRows = [
    ...TIER_MATERIALS.map((m) => reviewRow(m.labelAr, tierLabel(state.pricing[m.key]))),
    ...FIXED_OR_CUSTOM_MATERIALS.map((m) =>
      reviewRow(
        m.labelAr,
        state.pricing[m.key].tier === PRICE_TIERS.CUSTOM
          ? `مخصص — ${state.pricing[m.key].customPrice ?? "—"} د.أ`
          : `افتراضي — ${m.defaultPrice} د.أ`
      )
    ),
  ].join("");

  return `
    <div class="step-content">
      ${reviewSection("نوع المبنى والمواصفات", specsRows)}
      ${reviewSection("الخيارات", optionsRows)}
      ${reviewSection("مستويات الأسعار", pricingRows)}

      <button type="button" id="calculate-btn" class="btn-primary btn-full">
        احسب الكميات والتكلفة
      </button>
    </div>
  `;
}
