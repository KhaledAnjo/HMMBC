// =====================================================================
// section1.js
// القسم 1: معلومات المبنى الأساسية
// - "عدد الشقق" يختفي تلقائياً إذا نوع المبنى فيلا
// - لنوع "تكملة بناء طابق": الحقل يصير "عدد الطوابق المضافة"
//   + حقل "طوابق المبنى القائم" (يلزم لحساب وقفات المصعد)
// - إضافة "فئة تنظيم الأرض" (لفحص معايير أمانة عمان بالنتائج)
// =====================================================================

import { numberField, selectField } from "./fieldTemplates.js";
import { t } from "../i18n.js";

function landCategoryOptions() {
  return [
    { value: "unknown", labelAr: t("landCatUnknown") },
    { value: "A", labelAr: t("landCatA") },
    { value: "B", labelAr: t("landCatB") },
    { value: "C", labelAr: t("landCatC") },
    { value: "D", labelAr: t("landCatD") },
  ];
}

export function renderSection1(state) {
  const isVilla = state.buildingType === "villa";
  const isFloorAddition = state.buildingType === "floorAddition";

  return `
    <h2 class="section-title">${t("section1Title")}</h2>
    <div class="step-content">
      <div class="grid-2">
        ${numberField("numFloors", isFloorAddition ? t("numAddedFloorsLabel") : t("numFloorsLabel"), state.numFloors, { min: 1 })}
        ${
          isFloorAddition
            ? numberField("existingFloors", t("existingFloorsLabel"), state.existingFloors, { min: 1 })
            : ""
        }
        ${numberField("floorAreaSqm", t("floorAreaLabel"), state.floorAreaSqm, { min: 1, unit: "m²" })}
        ${numberField("ceilingHeight", t("ceilingHeightLabel"), state.ceilingHeight, { min: 2.4, step: 0.1, unit: "m" })}
        ${
          isVilla
            ? ""
            : numberField("numApartments", isFloorAddition ? t("numNewApartmentsLabel") : t("numApartmentsLabel"), state.numApartments, { min: 1 })
        }
        ${numberField("actualPerimeterM", t("actualPerimeterLabel"), state.actualPerimeterM, {
          min: 0, step: 0.1, unit: t("perimeterUnitHint"), required: false,
          placeholder: t("perimeterPlaceholder"),
        })}
        ${selectField("landCategory", t("landCategoryLabel"), state.landCategory, landCategoryOptions(), { required: false })}
        ${numberField("landAreaSqm", t("landAreaLabel"), state.landAreaSqm, { min: 0, unit: t("landAreaUnitHint"), required: false })}
      </div>

      <p class="hint-text">${isFloorAddition ? t("floorAdditionHintText") : t("perimeterHintText")}</p>

      ${state.buildingType === "fullBuilding" ? garageBlock(state) : ""}
    </div>
  `;
}

/**
 * بلوك الكراج — إجباري بنوع "مبنى كامل".
 * الكراج طابق مستقل: يا تسوية تحت الأرض يا طابق صفري (الأول)،
 * وما بينحسب من عدد الطوابق السكنية المُدخلة فوق.
 */
function garageBlock(state) {
  const mode = state.garageAreaMode || "full";
  return `
    <div class="garage-block">
      <h3 class="subsection-title">🚗 ${t("garageTitle")}</h3>
      <p class="notice-box garage-required-note">${t("garageRequiredNote")}</p>

      <div class="field-group" data-field-wrapper="garageLocation">
        <label>${t("garageLocationLabel")}<span class="required">*</span></label>
        <div class="btn-group" data-group>
          <button type="button" class="btn-choice ${state.garageLocation !== "ground" ? "active" : ""}"
            data-field="garageLocation" data-value="basement">${t("garageBasement")}</button>
          <button type="button" class="btn-choice ${state.garageLocation === "ground" ? "active" : ""}"
            data-field="garageLocation" data-value="ground">${t("garageGround")}</button>
        </div>
      </div>

      <div class="field-group" data-field-wrapper="garageAreaSqm">
        <label>${t("garageAreaLabel")}<span class="required">*</span></label>
        <div class="btn-group" data-group>
          <button type="button" class="btn-choice ${mode === "full" ? "active" : ""}"
            data-field="garageAreaMode" data-value="full">${t("garageAreaFull")}</button>
          <button type="button" class="btn-choice ${mode === "custom" ? "active" : ""}"
            data-field="garageAreaMode" data-value="custom">${t("garageAreaCustom")}</button>
        </div>
        ${
          mode === "custom"
            ? `<input type="number" data-field="garageAreaSqm" data-type="number"
                value="${state.garageAreaSqm ?? ""}" min="1" step="1"
                placeholder="${t("garageAreaPlaceholder")}" />`
            : `<span class="unit-hint">= ${state.floorAreaSqm || 0} m² (${t("garageAreaFullHint")})</span>`
        }
        <span class="field-error" data-error-for="garageAreaSqm"></span>
      </div>

      ${numberField("garageHeightM", t("garageHeightLabel"), state.garageHeightM, {
        min: 2.4, step: 0.1, unit: "m",
      })}

      <p class="hint-text">${t("garageHintText")}</p>
    </div>
  `;
}

export function validateSection1(data) {
  const errors = {};
  const isVilla = data.buildingType === "villa";
  const isFloorAddition = data.buildingType === "floorAddition";
  if (!data.numFloors || data.numFloors < 1) errors.numFloors = t("errRequired");
  if (isFloorAddition && (!data.existingFloors || data.existingFloors < 1)) {
    errors.existingFloors = t("errRequired");
  }
  if (!data.floorAreaSqm || data.floorAreaSqm <= 0) errors.floorAreaSqm = t("errRequired");
  if (!data.ceilingHeight || data.ceilingHeight <= 0) errors.ceilingHeight = t("errRequired");
  if (!isVilla && (!data.numApartments || data.numApartments < 1)) {
    errors.numApartments = t("errRequired");
  }

  // الكراج — إجباري بالمبنى الكامل
  if (data.buildingType === "fullBuilding") {
    if (data.garageAreaMode === "custom" && (!data.garageAreaSqm || data.garageAreaSqm <= 0)) {
      errors.garageAreaSqm = t("errRequired");
    }
    if (!data.garageHeightM || data.garageHeightM < 2.4) {
      errors.garageHeightM = t("errGarageHeight");
    }
  }
  return errors;
}
